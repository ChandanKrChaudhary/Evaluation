function sidebar() {


    // return your html component here
    //Make sure to give input search box id as ""

    return `
    
    <div id="">Masai News</div>
    <div>LogIn</div>
    <input  type="text" id="searchbar" placeholder="search news">
    <div>Startups</div>
    <div>Audio</div>
    <div>Video</div>
    
    `;
}
export default sidebar