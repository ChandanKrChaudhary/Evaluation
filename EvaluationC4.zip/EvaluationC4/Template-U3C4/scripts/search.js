function storeSearchterm(term) {



}

export default storeSearchterm